package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class UserVO {
	private String email;
	private String password;
	private String username;
	private String cell_phone;
	private String user_key;
	private String sub_date;
	private int user_sort_code;
	private int point;
	private String pref_code;
}
