(function ($) {

    $.fn.switchDiv = function (options) {
        return this.each(function () {
            $.switchDiv(this, options);
        });
    };

    $.fn.yesSlide = function (options) {
        return this.each(function () {
            $.yesSlide(this, options);
        });
    };

    $.fn.sjDiv = function (options) {
        return this.each(function () {
            $.sjDiv(this, options);
        });
    };

    $.fn.selectBox = function (options) {
        return this.each(function () {
            $.selectBox(this, options);
        });
    };

    $.fn.selectNorBox = function (options) {
        return this.each(function () {
            $.selectNorBox(this, options);
        });
    };

    $.fn.iptNorBox = function (options) {
        return this.each(function () {
            $.iptNorBox(this, options);
        });
    };

    $.fn.txtNorBox = function (options) {
        return this.each(function () {
            $.txtNorBox(this, options);
        });
    };

    $.fn.iptChkBox = function (options) {
        return this.each(function () {
            $.iptChkBox(this, options);
        });
    };

    $.fn.radioNorBox = function (options) {
        return this.each(function () {
            $.radioNorBox(this, options);
        });
    };

    $.fn.radioTabBox = function (options) {
        return this.each(function () {
            $.radioTabBox(this, options);
        });
    };

    $.fn.switchMove = function (current) {
        return this.each(function () {
            $.switchMove(this, current);
        });
    };

    $.fn.adultImageConvert = function (parent, options) {
        return $.adultImageConvert(parent, options);
    }

    $.fn.yesRolling = function (options) {
        return this.each(function () {
            $.yesRolling(this, options);
        });
    }

    $.switchMove = function (container, current) {
        var settings = $(container).data('settings');

        settings.prevcurrent = settings.current;
        settings.current = current;

        settings.showList(current);
        settings.moveEvent(this, settings, settings.current);
    };

    // 슬라이드 DIV 01
    $.switchDiv = function (container, options) {
        var settings = {
            auto: false,
            autoTimerId: null,
            play_time: 4500,
            current: 0, // 시작하는 값
            prevcurrent: null, // 이전 current 값
            pageBtnsClassSelector: null,
            pageNumTextSelector: null,
            pageTagInContainer: false,
            total_num: $(container).children().length, // 배너전체 개수
            wrapperId: null,
            moveEvent: function (obj, settings, index) { },
            stopEvent: function (obj, settings, index) { },
            showList: function (index) { },
            sShowBtn: false,
            isRandom: false,
            etc: null
        };
        if (options) { $.extend(settings, options); };

        // 토탈갯수 다시체크
        settings.total_num = settings.pageTagInContainer ? $(container).children().length - 3 : $(container).children().length;

        // settings.total_num -= $(container).find('script').length;
        $(container).children().each(
            function (i) {
                if (this.nodeName == "SCRIPT") {
                    settings.total_num -= 1;
                }
            }
        );

        // 랜덤 번호 추출
        if (settings.isRandom) {
            var _dateRnIdx = new Date().getMilliseconds() % settings.total_num;
            settings.current = _dateRnIdx;
        }

        // 전체갯수 초기화
        var initPageNum = function (pageNumObject) {
            $(pageNumObject).html("<strong>" + (settings.current + 1) + "</strong>/" + settings.total_num)
        };

        // 현재갯수 체크
        if (settings.total_num <= settings.current)
            settings.current = 0;

        // 리스트 보이기
        var showList = function (current) {
            var _childList = childList.not('script');
            _childList.css("display", "none");
            _childList.eq(current).css("display", "");

            initPageNum(pageNumNode);
        };

        settings.showList = showList;

        // 페이지 태그 찾기
        var leftPageBtn = null;
        var rightPageBtn = null;

        // 리스트 노드
        var childList = null;
        var pageNumNode = null;

        // 페이징 버튼 클래스 셀렉터가 있을경우
        if (settings.pageBtnsClassSelector != null) {
            var pageBtns = $(container).parent().find(settings.pageBtnsClassSelector);
            leftPageBtn = $(pageBtns[0]);
            rightPageBtn = $(pageBtns[1]);

            // 초기화
            childList = $(container).children().css("display", "none");
            if (settings.pageNumTextSelector != null)
                pageNumNode = $(container).parent().find(settings.pageNumTextSelector);
            else
                pageNumNode = $(container).next();
        }
        else {
            if (settings.pageTagInContainer) {
                rightPageBtn = $(container).children().eq(total_num - 1);
                leftPageBtn = $(container).children().eq(total_num - 2);

                // 초기화 
                childList = $(container).children().not('nth-last-child(1), nth-last-child(2), nth-last-child(3)').css("display", "none");

                if (settings.pageNumTextSelector != null)
                    pageNumNode = $(settings.pageNumTextSelector);
                else
                    pageNumNode = $(container).find('nth-last-child(3)');
            }
            else {
                rightPageBtn = $(container).next().next().next();
                leftPageBtn = $(container).next().next();

                // 초기화
                childList = $(container).children().css("display", "none");

                if (settings.pageNumTextSelector != null)
                    pageNumNode = $(settings.pageNumTextSelector);
                else
                    pageNumNode = $(container).next();
            }

            initPageNum(pageNumNode);
        }

        showList(settings.current);

        if (settings.current != null)
            settings.moveEvent(this, settings, settings.current);

        // wrraper
        var wrraper = null;

        // 컨테이너 이벤트 바인딩
        // 컨테이너 오버시 페이징 버튼 보이기
        if (settings.wrapperId != null) {
            wrraper = $(settings.wrapperId);
        }
        else {
            wrraper = $(container).parent();
        }

        if (!settings.isShowBtn) {
            wrraper.bind('mouseover', function () {
                if (settings.total_num > 0) {
                    rightPageBtn.show();
                    leftPageBtn.show();
                }
            });

            // 컨테이너 나갈시 페이징 버튼 숨기기
            wrraper.bind('mouseleave', function () {
                rightPageBtn.hide();
                leftPageBtn.hide();
            });
        }

        leftPageBtn.bind('click', function () {
            var _dataSetting = get_settings();

            _dataSetting.prevcurrent = _dataSetting.current;

            if (_dataSetting.current == 0)
                _dataSetting.current = _dataSetting.total_num - 1;
            else
                _dataSetting.current--;

            showList(_dataSetting.current);
            fireMoveEvent(this, _dataSetting, _dataSetting.current);
            setSettingData(container, _dataSetting);
        });

        rightPageBtn.bind('click', function () {
            nextMove();
        });

        $(container).parent().bind('mouseover focus', function () {
            var _dataSetting = get_settings();

            if (settings.auto) {
                stopPlay(this, _dataSetting, _dataSetting.current);
            }
        });

        $(container).parent().bind('mouseleave blur', function () {
            if (settings.auto) {
                settings.autoTimerId = setInterval(function () {
                    nextMove();
                }, settings.play_time);
            }
        });

        setSettingData(container, settings);

        if (settings.auto) {
            settings.autoTimerId = setInterval(function () {
                nextMove();
            }, settings.play_time);
        }

        // next
        function nextMove() {
            var _dataSetting = get_settings();

            _dataSetting.prevcurrent = _dataSetting.current;

            if (_dataSetting.current == _dataSetting.total_num - 1)
                _dataSetting.current = 0;
            else
                _dataSetting.current++;

            showList(_dataSetting.current);
            fireMoveEvent(this, _dataSetting, _dataSetting.current);
            setSettingData(container, _dataSetting);
        }

        // next move stop
        function stopPlay(obj, settings, current) {
            if (settings.autoTimerId != 0) {
                fireStopEvent(obj, settings, current);
                clearInterval(settings.autoTimerId);
            };
            settings.autoTimerId = 0;
        }

        // 이동후 발생 이벤트
        function fireMoveEvent(obj, settings, index) {
            settings.moveEvent(obj, settings, index);
        }

        // 정지시 발생 이벤트
        function fireStopEvent(obj, settings, index) {
            settings.stopEvent(obj, settings, index);
        }

        // 셋팅값 저장
        function setSettingData(container, settings) {
            $(container).data('settings', settings);
        }

        function get_settings() {
            return settings; // $(container).data('settings');
        }
    };

    // 슬라이드 DIV 02
    $.yesSlide = function (container, options) {
        var settings = {
            auto: false,
            autoTimerId: null,
            play_time: 4500,
            current: 0, // 시작하는 값
            //prevcurrent: null, // 이전 current 값
            wrapperId: null, //bgColor변경
            pageBtnsClassSelector: ".btnMbn",
            rollOnSelector: "rollOn",
            slideGrpSelector: ".sectorLi",
            slideGrpTabSelector: ".sectorTxt",
            slideSelector: ".mbnLi",
            slideTabSelector: ".mbnTxt",
            slideGrpOnSelector: "secOn",
            slideOnSelector: "liOn",
            total_num: 0, // 배너전체 개수
            showList: function (index) { },
            isRandom: false,
            etc: null
        };
        if (options) { $.extend(settings, options); };

        // 토탈갯수 체크
        settings.total_num = $(container).find(settings.slideSelector).length;

        // 랜덤 번호 추출
        // 시간으로 땡기면 중복확률이 적다
        if (settings.isRandom) {
            var _dateRnIdx = new Date().getMilliseconds() % settings.total_num;
            settings.current = _dateRnIdx;
        }

        // 현재갯수 체크
        if (settings.total_num <= settings.current)
            settings.current = 0;

        // 리스트그룹 & 리스트 노드
        var childGrp = null;
        var childList = null;

        // 리스트 보이기
        var showList = function (current) {
            $(container).find(settings.slideGrpSelector).removeClass(settings.slideGrpOnSelector);
            $(container).find(settings.slideSelector).removeClass(settings.slideOnSelector);

            $(container).find(settings.slideSelector).eq(current).addClass(settings.slideOnSelector);
            $(container).find(settings.slideSelector).eq(current).parent().parent().addClass(settings.slideGrpOnSelector);

            $(settings.wrapperId).css("background-color", $(container).find(settings.slideSelector).eq(current).attr("data_bgColor"));
        };

        settings.showList = showList;

        // 버튼 정의 
        var leftPageBtn = null;
        var rightPageBtn = null;
        var pageBtns = $(container).parent().find(settings.pageBtnsClassSelector);
        leftPageBtn = $(pageBtns[0]);
        rightPageBtn = $(pageBtns[1]);

        // 리스트 초기화
        childGrp = $(container).find(settings.slideGrpSelector).removeClass(settings.slideGrpOnSelector);
        childList = $(container).find(settings.slideSelector).removeClass(settings.slideOnSelector);

        // 리스트 인덱스 부여
        childList.each(function (index) {
            $(this).attr("data_idx", index);
        });

        //리스트 Show함수 실행
        showList(settings.current);

        // wrraper
        var wrraper = null;

        // 컨테이너 이벤트 바인딩
        // 컨테이너 오버시 페이징 버튼 보이기
        if (settings.wrapperId != null) {
            wrraper = $(settings.wrapperId);
        } else {
            wrraper = $(container);
        }

        $(container).bind('mouseover', function () {
            rightPageBtn.show();
            leftPageBtn.show();
        });

        // 컨테이너 나갈시 페이징 버튼 숨기기
        $(container).bind('mouseleave', function () {
            rightPageBtn.hide();
            leftPageBtn.hide();
        });

        function get_settings() {
            return settings; // $(container).data('settings');
        }

        // 셋팅값 저장
        function setSettingData(container, settings) {
            $(container).data('settings', settings);
        }

        // next
        function prevMove() {
            var _dataSetting = get_settings();

            if (_dataSetting.current == 0)
                _dataSetting.current = _dataSetting.total_num - 1;
            else
                _dataSetting.current--;

            showList(_dataSetting.current);
            setSettingData(container, _dataSetting);
        }

        // next
        function nextMove() {
            var _dataSetting = get_settings();

            _dataSetting.prevcurrent = _dataSetting.current;

            if (_dataSetting.current == _dataSetting.total_num - 1)
                _dataSetting.current = 0;
            else
                _dataSetting.current++;

            showList(_dataSetting.current);
            setSettingData(container, _dataSetting);
        }

        leftPageBtn.bind('click', function () {
            prevMove()
        });

        rightPageBtn.bind('click', function () {
            nextMove();
        });

        $(container).bind('mouseover focus', function () {
            var _dataSetting = get_settings();

            if (settings.auto) {
                $(container).removeClass(settings.rollOnSelector);
                stopPlay(this, _dataSetting, _dataSetting.current);
            }
        });

        $(container).bind('mouseleave blur', function () {
            if (settings.auto) {
                $(container).addClass(settings.rollOnSelector);
                settings.autoTimerId = setInterval(function () {
                    nextMove();
                }, settings.play_time);
            }
        });

        setSettingData(container, settings);

        if (settings.auto) {
            settings.autoTimerId = setInterval(function () {
                $(container).addClass(settings.rollOnSelector);
                nextMove();
            }, settings.play_time);
        }

        // next move stop
        function stopPlay(obj, settings, current) {
            if (settings.autoTimerId != 0) {
                clearInterval(settings.autoTimerId);
            };
            settings.autoTimerId = 0;
        }

        // sub tab Btn
        $(container).find(settings.slideGrpSelector + " " + settings.slideTabSelector + " a").bind('mouseover focus', function () {
            $(container).find(settings.slideGrpSelector).removeClass(settings.slideGrpOnSelector);
            $(container).find(settings.slideSelector).removeClass(settings.slideOnSelector);

            $(this).parent().parent().parent().parent().addClass(settings.slideGrpOnSelector);
            $(this).parent().parent().addClass(settings.slideOnSelector);

            var _dataSetting = get_settings();
            _dataSetting.current = $(this).parent().parent().attr("data_idx");
            setSettingData(container, _dataSetting);

            if (settings.wrapperId != null) {
                wrraper.css("background-color", $(this).parent().parent().attr("data_bgColor"));
            }
        });

        // tab Btn
        $(container).find(settings.slideGrpSelector + " " + settings.slideGrpTabSelector + " a").bind('mouseover focus', function () {
            $(container).find(settings.slideGrpSelector).removeClass(settings.slideGrpOnSelector);
            $(container).find(settings.slideSelector).removeClass(settings.slideOnSelector);

            var subTabLen = $(this).parent().parent().find(settings.slideSelector).length;
            var subTabNum = new Date().getMilliseconds() % subTabLen;

            $(this).parent().parent().addClass(settings.slideGrpOnSelector);
            $(this).parent().parent().find(settings.slideSelector).eq(subTabNum).addClass(settings.slideOnSelector);

            var _dataSetting = get_settings();
            _dataSetting.current = $(this).parent().parent().find(settings.slideSelector).eq(subTabNum).attr("data_idx");
            setSettingData(container, _dataSetting);

            if (settings.wrapperId != null) {
                wrraper.css("background-color", $(this).parent().parent().find(settings.slideSelector).eq(subTabNum).attr("data_bgColor"));
            }
        });
    };

    // 슬라이드 DIV 02
    $.sjDiv = function (container, options) {
        var settings = {
            auto: false,
            autoTimerId: null,
            play_time: 4500,
            m_num: 2, // 한번에 보여지는 개수
            pageSelector_id: "",
            pageTxtSelector_s: ".pagen_s",
            pageTxtSelector_m: ".pagen_m",
            firstClass_s: "sFirstCard",
            firstClass_m: "mFirstCard",
            lastClass_s: "sLastCard",
            lastClass_m: "mLastCard",
            onClass_s: "sOn",
            onClass_m: "mOn",
            showList: function (index) { },
            isRandom: false,
            etc: null
        };
        if (options) { $.extend(settings, options); };

        var curNum_s = 0; //현재 싱글 num
        var curNum_m = 0; //현재 멀티 num

        // 토탈갯수 다시체크
        var totNum_s = $(container).children().length; //총 싱글 개수
        var totNum_m = Math.ceil(totNum_s / settings.m_num); //총 멀티 개수

        // 현재 번호
        if (settings.isRandom) {
            curNum_s = Math.floor(Math.random() * totNum_s);
            curNum_m = Math.floor(curNum_s / settings.m_num);
        } else {
            curNum_s = 0;
            curNum_m = 0;
        }

        var pageNum = null;
        var pageBtnPrev = null;
        var pageBtnNext = null;

        // 초기 세팅
        if (settings.pageSelector_id == "") {
            pageNum = $(container).next();
            pageBtnPrev = $(container).next().next();
            pageBtnNext = $(container).next().next().next();
        } else {
            pageNum = $(container).parent().find("#" + settings.pageSelector_id);
            pageBtnPrev = pageNum.next();
            pageBtnNext = pageNum.next().next();
        }
        pageNum.find(settings.pageTxtSelector_s).html("<strong>" + (curNum_s + 1) + "</strong>/" + totNum_s);
        pageNum.find(settings.pageTxtSelector_m).html("<strong>" + (curNum_m + 1) + "</strong>/" + totNum_m);

        $(container).children().eq(curNum_s).addClass(settings.onClass_s);

        var sNum = curNum_m * settings.m_num;
        var tNum = sNum + settings.m_num;
        for (var i = sNum; i < tNum ; i++) {
            $(container).children().eq(i).addClass(settings.onClass_m);
        }
        if (curNum_s <= 0) {
            $(container).parent().addClass(settings.firstClass_s);
        } else if (curNum_s >= totNum_s) {
            $(container).parent().addClass(settings.lastClass_s);
        }
        if (curNum_m <= 0) {
            $(container).parent().addClass(settings.firstClass_m);
        } else if (curNum_m >= totNum_m) {
            $(container).parent().addClass(settings.lastClass_m);
        }

        pageBtnPrev.bind('click', function () {
            curNum_s--;
            if (curNum_s < 0) {
                curNum_s = totNum_s - 1;
            }
            if (curNum_s <= 0) {
                $(container).parent().addClass(settings.firstClass_s);
            } else {
                $(container).parent().removeClass(settings.lastClass_s);
                $(container).parent().removeClass(settings.firstClass_s);
            }
            curNum_m--;
            if (curNum_m < 0) {
                curNum_m = totNum_m - 1;
            }
            if (curNum_m <= 0) {
                $(container).parent().addClass(settings.firstClass_m);
            } else {
                $(container).parent().removeClass(settings.lastClass_m);
                $(container).parent().removeClass(settings.firstClass_m);
            }
            pageNum.find(settings.pageTxtSelector_s).html("<strong>" + (curNum_s + 1) + "</strong>/" + totNum_s);
            pageNum.find(settings.pageTxtSelector_m).html("<strong>" + (curNum_m + 1) + "</strong>/" + totNum_m);

            $(container).children().removeClass(settings.onClass_s);
            $(container).children().eq(curNum_s).addClass(settings.onClass_s);

            $(container).children().removeClass(settings.onClass_m);
            var sNum = curNum_m * settings.m_num;
            var tNum = sNum + settings.m_num;
            for (var i = sNum; i < tNum ; i++) {
                $(container).children().eq(i).addClass(settings.onClass_m);
            }
        });

        pageBtnNext.bind('click', function () {
            curNum_s++;
            if (curNum_s >= totNum_s) {
                curNum_s = 0;
            }
            if (curNum_s >= totNum_s - 1) {
                $(container).parent().addClass(settings.lastClass_s);
            } else {
                $(container).parent().removeClass(settings.lastClass_s);
                $(container).parent().removeClass(settings.firstClass_s);
            }
            curNum_m++;
            if (curNum_m >= totNum_m) {
                curNum_m = 0;
            }
            if (curNum_m >= totNum_m - 1) {
                $(container).parent().addClass(settings.lastClass_m);
            } else {
                $(container).parent().removeClass(settings.lastClass_m);
                $(container).parent().removeClass(settings.firstClass_m);
            }
            pageNum.find(settings.pageTxtSelector_s).html("<strong>" + (curNum_s + 1) + "</strong>/" + totNum_s);
            pageNum.find(settings.pageTxtSelector_m).html("<strong>" + (curNum_m + 1) + "</strong>/" + totNum_m);

            $(container).children().removeClass(settings.onClass_s);
            $(container).children().eq(curNum_s).addClass(settings.onClass_s);

            $(container).children().removeClass(settings.onClass_m);
            var sNum = curNum_m * settings.m_num;
            var tNum = sNum + settings.m_num;
            for (var i = sNum; i < tNum ; i++) {
                $(container).children().eq(i).addClass(settings.onClass_m);
            }
        });
    }

    // 셀렉트 박스
    $.selectBox = function (container, options) {

        var settings = {
            changeEvent: function (container, obj, text, pVal) { },
            pramEtc: '',
            chkDim: false,
            dimSelector: 'dim',
            scopeText: 'a',
            dtSelector: 'dt',
            ddSelector: 'dd',
            liSelector: 'dd > ul > li'
        };
        if (options) { $.extend(settings, options); };

        var dt = $(container).find(settings.dtSelector);
        var dd = $(container).find(settings.ddSelector);
        var lis = $(container).find(settings.liSelector);

        // 클릭스 리스트 열고 닫기
        $(container).find('dt a').bind('click', function (event) {
            if ((!settings.chkDim) || (settings.chkDim && !$(container).hasClass(settings.dimSelector))) {
                if (dt.attr("class") == "on") {
                    $(container).removeClass("focusOn");
                    dt.attr("class", "");
                    dd.hide();
                } else {
                    $(container).addClass("focusOn");
                    dt.attr("class", "on");
                    dd.show();
                }
                event.stopPropagation();
            }
        });

        // 영역 밖에서 클릭 할 경우 닫기
        $('body').bind('click', function (event) {
            $(container).removeClass("focusOn");
            dd.hide();
            dt.attr("class", "");
        });

        // 리스트 항목 선택시 이벤트
        lis.bind('click', function (event) {
            var text = $(this).find(settings.scopeText).html();
            var parm;
            if (settings.pramEtc != '') {
                parm = $(this).find('a').attr(settings.pramEtc);
            }

            dt.find('a').html(text);

            settings.changeEvent(container, this, text, parm);
        });

    };

    //셀렉트 박스 Normal(개발자 위한 버전)
    $.selectNorBox = function (container, options) {

        var settings = {
            selSelector: 'select'
        };
        if (options) { $.extend(settings, options); };

        var selectForm = $(container).find(settings.selSelector);
        var initSText = selectForm.children('option:selected').text();

        selectForm.siblings('label').find("em.txt").text(initSText);

        selectForm.bind("focus", function () {
            $(this).parent().addClass('selOn');
        });

        selectForm.bind("blur", function () {
            $(this).parent().removeClass('selOn');
        });

        selectForm.bind("change", function () {
            var select_name = $(this).children('option:selected').text();
            $(this).siblings('label').find("em.txt").text(select_name);
            $(this).parent().removeClass('selOn');
        });
    };

    // input box label 연동
    $.iptNorBox = function (container, options) {

        var settings = {
            focusColor: false,
            btnDel: false,
            btnDelSelector: '.lnk_del',
            isCal: false,
            iptSelector: 'input[type=text],input[type=password]'
        };
        if (options) { $.extend(settings, options); };

        var iptForm = $(container).find(settings.iptSelector);
        var btnDelTar = $(container).find(settings.btnDelSelector);
        var IptSetTime;

        iptForm.bind("focus", function () {
            if (settings.focusColor) {
                $(this).parent().addClass("focusOn");
            }
            $(this).parent().addClass("labelHide");

            if (settings.btnDel) {
                $(this).parent().addClass("nowFocus");
            }
        });

        iptForm.bind("blur", function () {
            if (settings.focusColor) {
                $(this).parent().removeClass("focusOn");
            }
            if (settings.isCal) {
                dbChkSetTime = setTimeout(function () {
                    if (iptForm.val() == '') {
                        iptForm.parent().removeClass("labelHide");
                    }
                }, 300);
            } else {
                if ($(this).val() == '') {
                    $(this).parent().removeClass("labelHide");
                }
            }
            if (settings.btnDel) {
                IptSetTime = setTimeout(function () {
                    if (iptForm.parent().hasClass("nowFocus")) {
                        iptForm.parent().removeClass("nowFocus");
                    }
                }, 500);
            }
        });

        btnDelTar.bind("click", function () {
            iptForm.val("");
            iptForm.parent().removeClass("labelHide");
        });

    };

    // checkbox label 연동
    $.iptChkBox = function (container, options) {

        var settings = {
            iptSelector: 'input[type=checkbox]'
        };
        if (options) { $.extend(settings, options); };

        var iptChk = $(container).find(settings.iptSelector);

        iptChk.bind("change", function () {
            if ($(this).is(":checked")) {
                $(this).parent().addClass("chkOn");
            } else {
                $(this).parent().removeClass("chkOn");
            }
        });
    };

    // textarea box label 연동
    $.txtNorBox = function (container, options) {

        var settings = {
            lenCount: false,
            tLimit: 100,
            focusColor: false,
            iptSelector: 'textarea'
        };
        if (options) { $.extend(settings, options); };

        var iptForm = $(container).find(settings.iptSelector);

        if (settings.lenCount) {
            tLen = iptForm.val().length;
            if (tLen > settings.tLimit) {
                // The value exceeds the limit, contain it
                iptForm.val(iptForm.val().substring(0, settings.tLimit));
            } else {
                // Set the counter text
                iptForm.parent().find(".ipt_msg").html('<strong>' + tLen + '</strong>/' + settings.tLimit);
            }
        }

        iptForm.bind("focus", function () {
            if (settings.focusColor) {
                $(this).parent().addClass("focusOn");
            }
            $(this).parent().addClass("labelHide");
        });

        iptForm.bind("blur", function () {
            if (settings.focusColor) {
                $(this).parent().removeClass("focusOn");
            }
            if ($(this).val() == '') {
                $(this).parent().removeClass("labelHide");
            }
            if (settings.lenCount) {
                tLen = $(this).val().length;
                if (tLen > settings.tLimit) {
                    // The value exceeds the limit, contain it
                    $(this).val($(this).val().substring(0, settings.tLimit));
                } else {
                    // Set the counter text
                    $(this).parent().find(".ipt_msg").html('<strong>' + tLen + '</strong>/' + settings.tLimit);
                }
            }
        });

        iptForm.bind("keyup", function () {
            if (settings.lenCount) {
                tLen = $(this).val().length;
                if (tLen > settings.tLimit) {
                    // The value exceeds the limit, contain it
                    $(this).val($(this).val().substring(0, settings.tLimit));
                } else {
                    // Set the counter text
                    $(this).parent().find(".ipt_msg").html('<strong>' + tLen + '</strong>/' + settings.tLimit);
                }
            }
        });
    };

    // radio label 연동
    $.radioNorBox = function (container, options) {

        var settings = {
            grpSelector: '.yesRadio',
            iptSelector: 'input[type=radio]'
        };
        if (options) { $.extend(settings, options); };

        var iptRadio = $(container).find(settings.iptSelector);

        iptRadio.bind("change", function () {
            $(container).find(settings.grpSelector).removeClass("chkOn");
            if ($(this).is(":checked")) {
                $(this).parent().addClass("chkOn");
            } else {
                $(this).parent().removeClass("chkOn");
            }
        });

    };

    // radio label 연동
    $.radioTabBox = function (container, options) {

        var settings = {
            grpSelector: 'li',
            iptSelector: 'input[type=radio]'
        };
        if (options) { $.extend(settings, options); };

        var iptRadio = $(container).find(settings.iptSelector);

        iptRadio.bind("change", function () {
            $(container).find(settings.grpSelector).removeClass("selected");
            if ($(this).is(":checked")) {
                $(this).parent().parent().parent().addClass("selected");
            } else {
                $(this).parent().parent().parent().removeClass("selected");
            }
        });
    };

    // 롤링
    $.yesRolling = function (obj, options) {
        var item = $(obj);
        var itemLi = item.find("li");
        var height = itemLi.eq(0).height();
        var itemCnt = itemLi.length + 1;
        var i = 0;
        var firstNodeStr = "";

        if (itemCnt > 1) {
            firstNodeStr = itemLi.eq(0)[0].outerHTML;
        }

        var settings = {
            rollingTime: 300,
            intervalTime: 3000,
            overCount: 0,
            currentIdx: 0,
            ovrEvent: function (item, itemCnt) {
                itemLi = item.find("li");
                itemLi.eq(itemCnt - 1).remove();
                item.stop();
                item.attr("style", "");
                item.parent().addClass("ovr");
            },
            outEvent: function (event, obj) {
                if ($(obj).hasClass("ovr")) {
                    $(firstNodeStr).appendTo(itemLi.parent());
                    item.css("top", "-" + height * (i - 1) + "px");
                    $(obj).removeClass("ovr");
                }
            },
            changeEvent: function (obj, li, index) { }
        };

        if (options) { $.extend(settings, options); };

        $(firstNodeStr).appendTo(itemLi.parent());


        i = settings.currentIdx;
        if (i >= itemCnt) {
            i = 0;
        }
        item.css({ top: "-" + height * i + "px" });
        i++;

        //item.css("position", "absolute");
        var intervalFunc = function () {

            if (i % itemCnt == 0) {
                i = 1;
                item.css("top", "0px");
            }

            item.stop().animate({ top: "-" + height * i + "px" }, settings.rollingTime, "easeInCubic");

            if (settings.changeEvent != undefined && settings.changeEvent != null)
                settings.changeEvent(item, item.eq(i - 1), i);

            i++;
        }
        var func = setInterval(intervalFunc, settings.intervalTime);
        item.data('_ivFun', func);

        var itemParentOver = function () {
            settings.ovrEvent(item, itemCnt);
        }

        var overChkNo = 0;
        var isOver = false;
        var overInterval = null;
        var overCountFunc = function () {
            if (isOver) {
                overChkNo++;
                if (overChkNo > settings.overCount) {
                    itemParentOver();
                } else {
                    overInterval = setTimeout(overCountFunc, 200);
                }
            } else {
                overInterval = null;
            }
        }

        itemLi.bind('mouseover', function (event) {
            $(this).parent().find("li").removeClass("itemOvr");
            $(this).addClass("itemOvr");
        });

        item.parent().bind('mouseover', function (event) {
            if (settings.overCount < 1) {
                itemParentOver();
            } else {
                isOver = true;
                overInterval = setTimeout(overCountFunc, 150);
            }
            clearInterval(func);
        });

        item.parent().bind('mouseleave', function (event) {

            if ($(this).hasClass("ovr")) {
                func = setInterval(intervalFunc, settings.intervalTime);
            }

            settings.outEvent(event, this);

            isOver = false;
            overChkNo = 0;
            overInterval = null;
        });
    }

    $.adultImageConvert = function (parentObj, options) {
        var settings = {}

        if (options) { $.extend(settings, options); }

        var adultImg = 'http://image.yes24.com/sysimage/pd19_m.gif';

        if (settings.adultImg != undefined && settings.adultImg != null && settings.adultImg != '') {
            adultImg = settings.adultImg;
        }

        var arrayGoodsNos = new Array();
        var arrayPositionDepths = new Array();
        var arraySizes = new Array();

        var tempGoodsNo = null;
        var tempPositionDepth = null;
        var tempSize = null;
        var imgObjs = null;

        if (parentObj == undefined || parentObj == null)
            imgObjs = $('img[-adult-data*=]');
        else
            imgObjs = $(parentObj).find('img[-adult-data*=]');

        imgObjs.each(function (i) {
            tempGoodsNo = $(this).attr('-adult-data');
            tempPositionDepth = $(this).attr('-adult-depth');
            tempSize = $(this).attr('-adult-size');

            if (tempPositionDepth == undefined || tempPositionDepth == null)
                tempPositionDepth = 0;

            if (tempSize == undefined || tempSize == null)
                tempSize = '';
            else
                tempSize = '/' + tempSize;

            arrayGoodsNos.push(tempGoodsNo);
            arrayPositionDepths[tempGoodsNo] = tempPositionDepth;
            arraySizes[tempGoodsNo] = tempSize;
        })

        var goodsNos = arrayGoodsNos.join(',');

        $.ajax({
            type: "GET",
            contentType: "application/json",
            dataType: "jsonp",
            url: YES_HTTP_URL + "/Mall/Check/CheckAdultGoods?goodsNos=" + goodsNos,
            data: "",
            success: function (data) {
                for (var i = 0; i < data.SuccessGoodsNos.length; i++) {
                    var successNo = data.SuccessGoodsNos[i];

                    var thisObj = $('img[-adult-data="' + successNo + '"]');
                    var imgUrl = getImageUrl(successNo);

                    thisObj.attr('src', imgUrl);
                }

                for (var i = 0; i < data.ErrorCount; i++) {
                    var errorNo = data.ErrorGoodsNos[i];
                    var errorCode = data.ErrorCodes[i];

                    var thisObj = $('img[-adult-data="' + errorNo + '"]');

                    thisObj.each(function (i) {
                        var tempthis = $(this);
                        var thisParent = tempthis.parent();

                        var depth = tempthis.attr('-adult-depth');//arrayPositionDepths[errorNo];

                        // -1  : 성인상품 밴드 표시
                        // -2  : 성인상품 제한 표시
                        if (errorCode == -1) {

                            var imgUrl = getImageUrl(errorNo)

                            tempthis.attr('src', imgUrl);

                            var appendObj = thisParent;

                            if (depth >= 0) {

                                for (var pi = 0; pi < depth; pi++) {
                                    appendObj = appendObj.parent();
                                }
                            }
                            else {
                                for (var pi = 0; pi < Math.abs(depth) ; pi++) {
                                    appendObj = thisObj.parent();
                                }
                            }

                            if (appendObj != null)
                                $('<em class="ico_19 bgCateM">19세 이상 상품</em>').appendTo(appendObj);
                        }
                        else if (errorCode == -2) {
                            tempthis.attr('src', adultImg);
                        }
                    });
                }
            },
            error: function (data) {
                //alert(data);
            }
        });

        var getImageUrl = function (goodsNo) {
            var imgUrl = 'http://image.yes24.com/goods/' + goodsNo;
            var size = arraySizes[goodsNo];

            if (size != undefined && size != null && size != '')
                imgUrl += size;

            return imgUrl;
        }

        return imgObjs;
    }

    $.fn.filter2 = function (selector) {
        return this.pushStack(winnow(this, selector, true), "filter2", selector);
    }

    //YES LAYER POP
    $.yesPop = function (popId, obj, options) {
        var pop = $("#" + popId);
        var mask = null;
        var marginL = 0;
        var popT = 0;
        var cockTarget;
        var $obj = $(obj);
        var popPosition = "absolute";

        var settings = {
            mask: false,
            cock: false,
            cockW: 7, //cock width/2
            cockH: 10, //cock height
            cockClassSelector: ".popYUI_cock",
            pGap: 50, //popWidth
            pWidth: 760, //popWidth
            fixed: false, //fixed
            posTChg: false, // goods detail position top change
            posTGap: 0, // goods detail position top change
            posLft: null, //position Left
            posTop: null, //position top
            baseWidth: 960, // base width
            showOnly: true, // show opt only ? multi
            align: "objBottom",
            ajaxURL: "", // ajax opt
            ajaxCallBack: function () { },
            closeEvent: function (settings) { } // close event callback
        };

        // 이벤트 설정 함수        
        var bindEvent = function () {
            pop.find(".popYUI_close a").bind("click", function () {
                if ($("#maskYUI")) {
                    $("#maskYUI").hide();
                }
                pop.hide();
                settings.closeEvent(settings);
            });

            pop.find(".popYUIArea").css({
                "width": settings.pWidth + "px"
            })
        };

        var popPosSet = function () {
            if (!settings.mask) {
                if ($obj.css("display") == "inline") {
                    cockTarget = $obj.children()[0];
                    if (cockTarget == null) {
                        cockTarget = $obj;
                    }
                } else {
                    cockTarget = $obj;
                }

                var agent = navigator.userAgent.toLowerCase();
                if ((navigator.appName == 'Netscape' && navigator.userAgent.search('Trident') != -1) || (agent.indexOf("msie") != -1)) {
                    var gapW = 0;
                }
                else {
                    var jVer = $.fn.jquery.split('.');
                    if (jVer[0] > 1 || (jVer[0] == 1 && jVer[1] > 11)) {
                        var gapW = 0;
                    } else {
                        var gapW = 7;
                    }
                }

                if (settings.posLft == null) {
                    marginL = ($(cockTarget).offset().left + ($(cockTarget).width() / 2)) - ($(window).width() / 2) - (settings.pWidth / 2) + gapW;
                } else {
                    marginL = ($(cockTarget).offset().left + ($(cockTarget).width() / 2)) - ($(window).width() / 2) - (settings.pWidth / 2) + gapW + settings.posLft;
                }

                var targetX = $(window).width() / 2 + marginL;
                var targetXW = targetX + settings.pWidth;

                //만약 marginL이 baseWidth에 넘치면
                if (targetXW > ($(window).width() / 2) + (settings.baseWidth / 2)) {
                    var moveX = ($(window).width() / 2) + (settings.baseWidth / 2) - targetXW + settings.cockW; //cock 너비/2
                    marginL += moveX - settings.cockW;
                    if (settings.cock) {
                        pop.find(settings.cockClassSelector).css("margin-left", -moveX + "px");
                    }
                } else if (targetX < ($(window).width() / 2) - (settings.baseWidth / 2)) {
                    var moveX = ($(window).width() / 2) - (settings.baseWidth / 2) - targetX + settings.cockW; //cock 너비/2
                    marginL += moveX - settings.cockW;
                    if (settings.cock) {
                        pop.find(settings.cockClassSelector).css("margin-left", -moveX + "px");
                    }
                }

                if (settings.fixed) {
                    popPosition = "fixed";

                    if (settings.cock) {
                        popT = $(cockTarget).offset().top - $(window).scrollTop() + $(cockTarget).height() + settings.cockH;
                    } else {
                        popT = $(cockTarget).offset().top - $(window).scrollTop() + $(cockTarget).height() + 5;

                        if ((popT + pop.find(".popYUIArea").height()) > $(document).height()) {
                            popT = $(cockTarget).offset().top - $(window).scrollTop() - pop.find(".popYUIArea").height() - 5;
                        }
                    }
                    if (settings.align != "objBottom") {
                        popT -= (pop.find(".popYUIArea").height() + $(cockTarget).height() + 10);
                    }
                } else {
                    popPosition = "absolute";

                    if (settings.cock) {
                        popT = $(cockTarget).offset().top + $(cockTarget).height() + settings.cockH;
                    } else {
                        popT = $(cockTarget).offset().top + $(cockTarget).height() + 5;

                        if ((popT + pop.find(".popYUIArea").height()) > $(document).height()) {
                            popT = $(cockTarget).offset().top - pop.find(".popYUIArea").height() - 5;
                        }
                    }
                    if (settings.align != "objBottom") {
                        popT -= (pop.find(".popYUIArea").height() + $(cockTarget).height() + 10);
                    }
                }

            } else {
                if (settings.posLft == null) {
                    marginL = -Math.floor(settings.pWidth / 2);
                } else {
                    marginL = -Math.floor(settings.pWidth / 2) + settings.posLft - Math.floor((settings.baseWidth - settings.pWidth) / 2);
                }

                if (settings.posTop == null) {
                    if (settings.fixed) {
                        popPosition = "fixed";
                        popT = Math.floor(($(window).height() - pop.find(".yesPopUp").height()) / 2) - settings.pGap;
                    } else {
                        popT = $(window).scrollTop() + Math.floor(($(window).height() - pop.find(".yesPopUp").height()) / 2) - settings.pGap;
                    }
                } else {
                    if (settings.fixed) {
                        popPosition = "fixed";
                        popT = settings.posTop;
                    } else {
                        popT = $(window).scrollTop() + settings.posTop;
                    }
                }
                if (settings.align != "objBottom") {
                    popT -= (pop.find(".popYUIArea").height() + $(cockTarget).height() + 10);
                }
            }
        };

        if (options) { $.extend(settings, options); };

        if (settings.showOnly) {
            if ($("#maskYUI")) {
                $("#maskYUI").hide();
            }
        }

        if (settings.mask) {
            if ($("#maskYUI").length == 0) {
                $('body').append('<div id="maskYUI"></div>');
            }
            mask = $("#maskYUI");
            mask.stop().fadeIn();
        }

        if (settings.ajaxURL == "") {
            bindEvent();
            pop.show();
            popPosSet();

            // 페이지에 팝업 내용이 있을때
            pop.find(".yesPopUp").css({
                "position": popPosition,
                "marginLeft": marginL + "px",
                "top": popT + "px"
            });
            if (settings.posTChg) {
                pop.find(".yesPopUp").addClass("tPosChg");
                pop.find(".yesPopUp").attr("data-tpos", popT);
                pop.find(".yesPopUp").attr("data-tgap", settings.posTGap);
            }
        } else {
            // Ajax로 팝업 내용 가져올때
            $.ajax({
                url: settings.ajaxURL,
                type: 'get',
                success: function (result) {
                    pop.html(result);
                    bindEvent();
                    pop.show();
                    popPosSet();

                    pop.find(".yesPopUp").css({
                        "position": popPosition,
                        "marginLeft": marginL + "px",
                        "top": popT + "px"
                    });
                    if (settings.posTChg) {
                        pop.find(".yesPopUp").addClass("tPosChg");
                        pop.find(".yesPopUp").attr("data-tpos", popT);
                        pop.find(".yesPopUp").attr("data-tgap", settings.posTGap);
                    }
                    settings.ajaxCallBack();
                },
                error: function (error) {
                    //oneBtnDialog.show('알림', error, '확인');
                }
            });
        }

    }

})(jQuery);