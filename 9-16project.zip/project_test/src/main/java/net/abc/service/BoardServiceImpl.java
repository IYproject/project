package net.abc.service;

public class BoardServiceImpl implements BoardService {
	
}
