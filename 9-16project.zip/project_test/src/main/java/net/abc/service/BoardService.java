package net.abc.service;

public interface BoardService {

}
