package net.abc.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import net.abc.service.BoardService;

@Controller
public class IY_board {
	
	/*
	 * @Autowired BoardService boardService;
	 */
	
	@GetMapping("/IY_board_list")
	public String board_list(){
		return "board/board_list";
	}
	
	@GetMapping("/IY_board_write")
	public String board_write() {
		return "board/board_write";
	}
	@GetMapping("/IY_board_edit")
	public String board_edit() {
		return "board/board_edit";
	}
	@GetMapping("IY_board_cont")
	public String board_cont() {
		return "board/board_cont";
	}
	
	@PostMapping("/fileuploadAction")
	public void uploadAjaxAction(MultipartFile[] uploadFile) {
		System.out.println("update ajax post...");
		String uploadFolder = "C://upload";
		
		for(MultipartFile multipartFile:uploadFile) {
			String uploadFileName = multipartFile.getOriginalFilename();
			uploadFileName=uploadFileName.substring(uploadFileName.lastIndexOf("\\")+1);
			System.out.println("only file name : "+uploadFileName);
			File saveFile=new File(uploadFolder,uploadFileName);
			try {
				multipartFile.transferTo(saveFile);
			}catch(Exception e) {e.printStackTrace();}
		}//Ȯ�� for
	}//uploadAjaxAction()
	
}
