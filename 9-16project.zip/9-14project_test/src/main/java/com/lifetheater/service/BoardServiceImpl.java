package com.lifetheater.service;

public class BoardServiceImpl implements BoardService {
	
}
