package com.lifetheater.service;

import javax.servlet.http.HttpServletRequest;

import com.lifetheater.vo.UserVO;

public interface UserService {

	void mailSendWithUserKey(UserVO user, HttpServletRequest request);

	String confirmEmail(UserVO user);

	void change_key(UserVO user);

	String confirmPhone(UserVO user);
	
	//사용자 정보 조회
		UserVO searchUser(UserVO id);
		
		//자동로그인 쿠키값 db저장
		/* void keepLogin(String sessionId,Date limitDate,String email); */
		
		//세션 아이디로 회원 조회
		/* UserVO getUserSessionId(String sessionId); */
		
	

	

}
