package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class UserVO {
	private String email;
	private String pw;
	private String name;
	private String phone;
	private String user_key;
	private String reg_date;
	private int membertype;
	private int point;
	private String pref_theater01;
	private String pref_theater02;
	private String pref_theater03;
	private String login_way;
}

