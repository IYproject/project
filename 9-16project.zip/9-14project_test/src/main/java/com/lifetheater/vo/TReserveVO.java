package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class TReserveVO {
  private String res_code;
  private String ticket_code1;
  private String ticket_code2;
  private String ticket_code3;
  private String ticket_code4;
  private String location_code;
  private String theater_code;
  private String email;
}
