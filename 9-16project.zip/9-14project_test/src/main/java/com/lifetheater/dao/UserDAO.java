package com.lifetheater.dao;

import java.util.List;

import com.lifetheater.vo.UserVO;

public interface UserDAO {

	void sendEmail(UserVO user);

	String confirmEmail(UserVO user);

	void change_key(UserVO user);

	List<UserVO> selectUser();

	void autoDelUser();

	void testDel();

	String confirmPhone(UserVO user);
	

	//사용자 정보 조회
	UserVO searchUser(UserVO id);
	
}
