package com.lifetheater.controller;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;

@Controller
public class IY_board {
	
	/*
	 * @Autowired BoardService boardService;
	 */
	
	@GetMapping("/IY_board_flist")
	public String board_flist(){
		return "board/board_flist";
	}
	@GetMapping("/IY_board_fwrite")
	public String board_fwrite() {
		return "board/board_fwrite";
	}
	@GetMapping("/IY_board_fedit")
	public String board_fedit() {
		return "board/board_fedit";
	}
	@GetMapping("IY_board_fcont")
	public String board_fcont() {
		return "board/board_fcont";
	}

	@GetMapping("/IY_board_plist")
	public String board_plist(){
		return "board/board_plist";
	}
	@GetMapping("/IY_board_pwrite")
	public String board_pwrite() {
		return "board/board_pwrite";
	}
	@GetMapping("/IY_board_pedit")
	public String board_pedit() {
		return "board/board_pedit";
	}
	@GetMapping("IY_board_pcont")
	public String board_pcont() {
		return "board/board_pcont";
	}
	
	@GetMapping("/IY_board_nlist")
	public String board_nlist(){
		return "board/board_nlist";
	}
	@GetMapping("/IY_board_nwrite")
	public String board_nwrite() {
		return "board/board_nwrite";
	}
	@GetMapping("/IY_board_nedit")
	public String board_nedit() {
		return "board/board_nedit";
	}
	@GetMapping("IY_board_ncont")
	public String board_ncont() {
		return "board/board_ncont";
	}
	
	@PostMapping("board_fwrite_ok")
	public void board_fwrite_ok() {
		
	}
	
	@PostMapping(value="/uploadSummernoteImageFile", produces = "application/json")
	@ResponseBody
	public JsonObject uploadSummernoteImageFile(@RequestParam("file") MultipartFile multipartFile) {
		
		JsonObject jsonObject = new JsonObject();
		
		String fileRoot = "C:\\lifetheater\\board\\summernote_image\\";	//저장될 외부 파일 경로
		String originalFileName = multipartFile.getOriginalFilename();	//오리지날 파일명
		String extension = originalFileName.substring(originalFileName.lastIndexOf("."));	//파일 확장자
				
		String savedFileName = UUID.randomUUID() + extension;	//저장될 파일 명
		
		File targetFile = new File(fileRoot + savedFileName);	
		
		try {
			InputStream fileStream = multipartFile.getInputStream();
			FileUtils.copyInputStreamToFile(fileStream, targetFile);	//파일 저장
			jsonObject.addProperty("url", "/summernoteImage/"+savedFileName);
			jsonObject.addProperty("responseCode", "success");
				
		} catch (IOException e) {
			FileUtils.deleteQuietly(targetFile);	//저장된 파일 삭제
			jsonObject.addProperty("responseCode", "error");
			e.printStackTrace();
		}
		
		return jsonObject;
	}
	
	
	@PostMapping("/fileuploadAction")
	public void uploadAjaxAction(MultipartFile[] uploadFile) {
		System.out.println("update ajax post...");
		String uploadFolder = "C://upload";
		
		for(MultipartFile multipartFile:uploadFile) {
			String uploadFileName = multipartFile.getOriginalFilename();
			uploadFileName=uploadFileName.substring(uploadFileName.lastIndexOf("\\")+1);
			System.out.println("only file name : "+uploadFileName);
			File saveFile=new File(uploadFolder,uploadFileName);
			try {
				multipartFile.transferTo(saveFile);
			}catch(Exception e) {e.printStackTrace();}
		}
	}//uploadAjaxAction()
	
}
