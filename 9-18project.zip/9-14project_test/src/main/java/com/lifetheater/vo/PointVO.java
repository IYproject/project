package com.lifetheater.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PointVO {
  private String point_code;
  private String point_cont;
  private String point_date;
  private int point;
  private String email;
}
