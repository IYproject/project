package com.lifetheater.service;

import javax.servlet.http.HttpServletRequest;

import com.lifetheater.vo.UserVO;

public interface UserService {

	void mailSendWithUserKey(UserVO user, HttpServletRequest request);

	String confirmEmail(UserVO user);

	void change_key(UserVO user);

	

}
